from .login import Login
from .usrinfo import UserInfo

class classname(object):
    pass
